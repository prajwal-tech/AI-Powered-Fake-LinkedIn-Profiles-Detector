# 🚀 AI-Powered Fake LinkedIn Profile Detector

This project detects **fake LinkedIn profiles** by analyzing **profile pictures** and **AI-generated profile bios**.

## 🔍 Features
✅ **DeepFace Analysis** - Detects AI-generated or suspicious faces  
✅ **AI Text Detection** - Checks if profile bios were generated using ChatGPT  
✅ **Works on Google Colab** - Easy to test and use  

## 🚀 How to Use  
1. **Install dependencies:**  
   ```bash
   pip install deepface opencv-python matplotlib numpy openai
   ```  
2. **Replace `your-api-key-here`** in `main.py` with your OpenAI API Key.  
3. **Run the script:**  
   ```bash
   python main.py
   ```

## 📌 Future Enhancements  
- **Network Analysis** - Detect bot-like connection patterns  
- **Web App Version** (Flask/Streamlit)  

📢 **Like this project? Share it on LinkedIn!** 🚀  
