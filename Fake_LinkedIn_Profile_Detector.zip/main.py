import cv2
import numpy as np
import matplotlib.pyplot as plt
from deepface import DeepFace
import openai

# OpenAI API Key (Replace with your own if deploying)
OPENAI_API_KEY = "your-api-key-here"
openai.api_key = OPENAI_API_KEY

def detect_fake_profile(image_path):
    try:
        # Load the image
        img = cv2.imread(image_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # Analyze the image using DeepFace
        analysis = DeepFace.analyze(img_path=image_path, actions=['age', 'gender', 'race'], enforce_detection=False)

        # Extract details
        age = analysis[0]['age']
        gender = analysis[0]['dominant_gender']
        race = analysis[0]['dominant_race']

        # Display image
        plt.imshow(img_rgb)
        plt.axis("off")
        plt.title(f"Age: {age}, Gender: {gender}, Race: {race}")
        plt.show()

        return {"Age": age, "Gender": gender, "Race": race}
    except Exception as e:
        print(f"Error: {e}")
        return None

def detect_ai_generated_text(profile_text):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an AI that detects whether a given LinkedIn profile bio is AI-generated or human-written."},
                {"role": "user", "content": f"Analyze the following LinkedIn bio and determine if it was written by a human or AI: {profile_text}"}
            ]
        )
        
        result = response["choices"][0]["message"]["content"].strip()
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

# Example Usage
if __name__ == "__main__":
    image_path = "sample_profile.jpg"  # Upload a LinkedIn profile picture
    profile_text = "I am a highly motivated individual with experience in multiple domains. Passionate about AI and automation."

    # Detect Fake Profile Picture
    image_results = detect_fake_profile(image_path)
    print("Profile Image Analysis:", image_results)

    # Detect AI-Generated Profile Bio
    text_results = detect_ai_generated_text(profile_text)
    print("Profile Bio Analysis:", text_results)
